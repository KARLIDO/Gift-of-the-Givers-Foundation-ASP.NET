﻿namespace Gift_of_the_Givers_Foundation.Models
{
    public class Volunteer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Skills { get; set; }
        public string Availability { get; set; }
        public string ExperienceLevel { get; set; }
    }

}
